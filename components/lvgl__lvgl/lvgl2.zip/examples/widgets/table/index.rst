

Simple table
"""""""""""""""""""""""

.. lv_example:: widgets/table/lv_example_table_1
  :language: c

Lightweighted list from table
""""""""""""""""""""""""""""""

.. lv_example:: widgets/table/lv_example_table_2
  :language: c

